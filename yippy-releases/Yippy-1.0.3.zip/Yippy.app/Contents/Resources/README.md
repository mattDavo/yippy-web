# Yippy
An open source clipboard manager

## TODO
- [ ] Fix bug of retrieving pasteboard items that were put on by another application
- [ ] Support more types of pasteboard items
- [ ] Allow setting preferences for keyboard shortcuts
